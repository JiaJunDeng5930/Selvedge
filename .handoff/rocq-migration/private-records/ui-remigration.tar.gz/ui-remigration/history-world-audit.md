# History world responsibility audit

Reference: acfbe86d8181415fd887c323cbba6495509d280f.

- harness/history/MODEL.bend: Journal trace, advance, run, replay, edge and reachable; WorldInvariant.well_formed.
- harness/history/PROOF.bend: PacketProofs actual admission/packet preservation; JournalProofs actual-step/history/reachability/replay preservation, correspondence and receipt order.
- harness/history/README.md: theories/Kernel/README.md.

Original INVARIANTS.world decomposition:

- Canonical task IDs and next-task equality are supplied by registry position and length.
- Archived idle/no-operations is supplied by the Archived lifecycle constructor.
- Environment/instructions/catalog/plugin and frozen/effective contract validity: environment_valid, contract_valid, profile_valid, settings_valid.
- Projects and task bindings: projects_valid, project_valid, project_binding.
- Forest ancestry, ancestor tails, inherited creation resources and descendant quotas: lineage_valid, inherited_creation, task_valid.
- Pending calls, callable names, automatic reasoning sample: calls_valid, phase_valid, checked_phase, sampled_reasoning.
- Before-hook receipts/rewrite suffixes, operation existence/history and result rights: hooks_correspond, operation_history, operation_stage_valid.
- Latest exact one-operation approval grant: approval_corresponds and review_right. FullAccess direct elevated execution legitimately has no grant receipt.
- After-hook execution receipt, plugin order, rewrites and immutable error flag: results_correspond, after_step.
- Unique active correlations within supply, including feature requests: tickets_valid, task_tickets, feature_tickets.
- All eight FeatureState.valid responsibilities: titles_valid, remote_valid, worktrees_valid, board_valid, sharing_valid, graph_registry_valid, works_valid, compaction_valid. Current typed compaction policy/budgets/target/method supply original boundedness and supported-method constraints.
- Static positive execution fuel/frame budget are fixed constants in Limits.

World checks alone do not complete INVARIANTS.decision (retention and effect authority), so that original file remains pending.

Validation and completion accounting remain pending until current production extraction and public entry execution pass after the commit gate is connected.
