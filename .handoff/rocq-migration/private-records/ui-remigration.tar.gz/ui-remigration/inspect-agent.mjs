import { browserFixture } from '../../tests/fixtures/browser.mjs';
import { defaultConfig } from '../../host/config.mjs';
const clean=[]; const t={after(fn){clean.push(fn);}};
try {
 const f=await browserFixture(t); const {page}=f; const events=[];
 page.on('pageerror',e=>events.push({kind:'pageerror',message:String(e),stack:e.stack}));
 page.on('console',m=>{if(m.type()==='error')events.push({kind:'console',message:m.text(),location:m.location()});});
 await f.command({op:'save_board_agent',agent:'',revision:0,name:'Persisted inspection role',profile:f.profile,reasoning:'high',instructions:'Inspect the workspace.',concurrency:1});
 await f.restart({profiles:defaultConfig.profiles});
 await page.goto(f.running.url);
 await page.getByRole('navigation',{name:'Global navigation',exact:true}).getByRole('button',{name:'智能体',exact:true}).click();
 await page.waitForTimeout(1000);
 console.log(JSON.stringify({body:await page.locator('body').innerText(),semantics:await page.getByRole('main').evaluate(n=>[...n.querySelectorAll('[aria-label],[role]')].map(x=>({tag:x.tagName,role:x.getAttribute('role'),label:x.getAttribute('aria-label'),text:x.innerText}))),events},null,2));
}finally{for(const fn of clean.reverse())await fn();}
