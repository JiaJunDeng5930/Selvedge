import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { browserFixture } from '../../tests/fixtures/browser.mjs';

const cleanups = [];
const fixture = await browserFixture({ after: cleanup => cleanups.push(cleanup) });
const { page, root, command } = fixture;
const result = {};
try {
  const workspace = path.join(root, 'Role diagnostic');
  await mkdir(workspace);
  await command({ op: 'create_project', name: 'Role diagnostic', workspace: { roots: [workspace], primary_root: workspace } });
  await page.getByRole('navigation', { name: 'Global navigation', exact: true }).getByRole('button', { name: '项目', exact: true }).click();
  await page.getByText('Projects', { exact: true }).waitFor();
  result.before = await page.locator('main').evaluateAll(nodes => nodes.map(node => ({html: node.outerHTML, role: node.getAttribute('role'), hidden: node.hidden, style: getComputedStyle(node).display, ariaHidden: node.getAttribute('aria-hidden'), bounds: node.getBoundingClientRect().toJSON()})));
  result.counts = { main: await page.getByRole('main').count(), mainHidden: await page.getByRole('main', { includeHidden: true }).count(), action: await page.getByRole('button', {name: 'Project actions', exact: true}).count(), inMain: await page.getByRole('main').getByRole('button', {name:'Project actions',exact:true}).count() };
  result.snapshot = await page.locator('body').ariaSnapshot();
  result.actionStyles = await page.locator('main button[aria-label="Project actions"]').evaluateAll(nodes => nodes.map(node => ({ visibility: getComputedStyle(node).visibility, display: getComputedStyle(node).display, opacity: getComputedStyle(node).opacity, hidden: node.hidden, bounds: node.getBoundingClientRect().toJSON(), ancestors: [...(function* () { for (let p = node.parentElement; p; p = p.parentElement) yield p; })()].map(p => ({tag:p.tagName, label:p.getAttribute('aria-label'), visibility:getComputedStyle(p).visibility, display:getComputedStyle(p).display})) })));
  await page.getByRole('main').getByRole('region', { name: 'Role diagnostic', exact: true }).hover();
  result.hoverCount = await page.getByRole('main').getByRole('button', { name: 'Project actions', exact: true }).count();
  try { await page.getByRole('main').getByRole('button', { name: 'Project actions', exact: true }).click({timeout: 3000}); result.clicked = true; }
  catch (error) { result.error = String(error); }
} finally {
  await writeFile('.workpad/ui-remigration/project-role-diagnostic.json', JSON.stringify(result, null, 2));
  for (const cleanup of cleanups) await cleanup();
}
