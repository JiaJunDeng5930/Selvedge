# Current public-entry acceptance

Reference: `acfbe86d8181415fd887c323cbba6495509d280f`. Tests use public browser/API entry points; no production implementation was read by this agent.

## Corrections to previous test assumptions

- Project auxiliary actions require pointer or focus ownership. Original `browser/controls/NAVIGATION.bend::revealed` (62) defines this. Public probe: computed visibility hidden; hovering the Project region makes the action visible and clickable (`project-role-diagnostic.json`).
- Workspace preparation is required for explicit workspace overrides, not inherited Project settings. Original `interaction/experience/PROGRAM.bend::prepared_assessment` (1228). The directory case now selects Workspace / Use as primary before submitting the captured draft.
- Original graph control labels are Chinese: original `interaction/interactive_markdown/SCENE.bend` (196–198, 241) declares right pan, fit width, zoom out, and accessible node/rule lists. Tests now use the original labels. Public ready-state DOM is in `graph-before-list.json`.
- The responsive navigation dialog is Task tree; public state is captured in `public-ui-diagnostic.json`.
- The Workspace property uses Workspace / Remove directory / Use inherited workspace. Original `interaction/presentation/VIEW.bend` (380, 395) supplies the removal/inheritance names. Previous invented Workspace directories list expectations were replaced by the displayed workspace fact and existing effective-settings assertions.

## Current execution

`acceptance-current-bundle.log`: 12 cases, 9 pass / 3 fail. All directory-capture, supporting-control, approval, original UI and independent-title behavior passed. Two browser failures were the corrected names above. The saved-profile case failed before its value assertions because navigating after restart returned HTTP 503 with `stopping / Server is stopping`.

`directory-steps.log`: the same directory case with only event/stage logging passed in 24.3s, including command HTTP 200, accepted captured draft and preservation of later writing. Permanent timeout was not increased.

`profile-restart-diagnostic.json`: after `fixture.restart`, root navigation returns HTTP 503 with JSON `Server is stopping`; `/api/events` also returns 503. Dynamic running getter and same origin/path verified. This requires service/fixture lifecycle investigation; it is not a saved-profile rendering verdict.

The corrected original two-file command is running in `original-ui-browser-current.log`. No builder was run by this agent and no completion ledger was changed.

## Follow-up closure

The existing saved-profile case now passes after the service lifecycle fix: navigation HTTP 200 and retained profile/reasoning, 12.2s. `project-profile-current.log` reports 3 pass / 0 fail for it and the two distinct Project workspace contracts (25.1s inherited restoration, 21.7s explicit empty). The permanent 30s test budget was retained.

The original combined Project flow succeeded as a private public-entry experiment in 35.7s after fixture readiness (`project-stages.jsonl`). It was separated into two complete cases instead of raising the official timeout. Initial Project details/readable-guidance assertions remain in the inherited-restoration case.

Graph public experiments restored the valid snapshot and rejected the complete invalid snapshot. Reload returns while the body still says Loading the browser program; boot consumed 9–10s of the task click timeout. Permanent tests now wait for the public Global navigation landmark after reload. Graph interaction/atomic restoration and separate-document isolation are separate complete cases, retaining the existing 60s graph budget. Isolation now begins from a nonzero count and nonempty note, so the expected independent defaults are discriminating. Both Graph cases await execution after the latest full branch check.

The current suite has 14 cases: 12 distinct behaviors have passing evidence on the current production behavior; the two refactored Graph cases remain pending. No ledger was changed.

The original profile probe field named tokenChanged compared URL.search, not the real token; see profile-restart-diagnostic-correction.txt. That field must not support a token-identity claim. Actual HTTP503/stopping evidence was unaffected.

## Graph trace result

`graph-traced-current.log`: graph interaction/atomic-restoration case passed in 57.2s with the original 60s budget and full trace enabled. The private copy was byte-for-byte identical to the permanent test source after substituting only the traced fixture/support imports.

The separate-document case reached the expected visible second document, Count 0 and empty note, but its helper timed out before the assertions because the click's 10s auto-wait included delayed appearance, actionability and navigation completion. The trace contains 46 HTTP responses, all 200, and no page error. Locator appeared at +3.5s; action began at +6.1s; it was stable at +7.6s; native click completed at +8.6s; navigation waiting expired at +10s. `graph-isolation-last.jpeg` shows the correct second document and defaults. This is evidence for the visible outcome, not a passing test verdict.

Trace: `the-same-graph-definition-in-another-Task-keeps-an-independent-local-s.trace.zip`. Formal current coverage is 13 passing distinct cases, with the final document-isolation case awaiting a faithful public-readiness synchronization correction and rerun. Browser execution is paused for the root branch check/extraction window.
