import { browserFixture } from '../../tests/fixtures/browser.mjs';
import { taskIdle } from '../../tests/support.mjs';
import { setTimeout as delay } from 'node:timers/promises';
const clean=[]; const t={after(fn){clean.push(fn);}};
try{
 const f=await browserFixture(t),{page}=f,events=[];
 page.on('pageerror',e=>events.push({kind:'pageerror',message:String(e),stack:e.stack}));
 page.on('response',async r=>{if(r.status()>=400 && new URL(r.url()).pathname.startsWith('/api/'))events.push({kind:'response',path:new URL(r.url()).pathname,status:r.status(),body:await r.text()});});
 await f.command({op:'create_project',name:'Inspect Project Page',workspace:{roots:[f.root],primary_root:f.root}});
 await page.getByRole('navigation',{name:'Global navigation',exact:true}).getByRole('button',{name:'项目',exact:true}).click();
 const button=page.getByRole('main').getByRole('button',{name:'Inspect Project Page',exact:true});
 await button.waitFor();
 const projectGroup=await page.getByRole('main').evaluate(n=>n.outerHTML);
 const more=page.getByRole('main').getByRole('button',{name:/^More/});
 if(await more.count())await more.first().click(); await page.waitForTimeout(300);
 const menu={body:await page.locator('body').innerText(),roles:await page.locator('[role="menu"],[role="menuitem"]').evaluateAll(ns=>ns.map(n=>({role:n.getAttribute('role'),label:n.getAttribute('aria-label'),text:n.innerText})))};
 await page.keyboard.press('Escape');
 const index=f.requests.length;
 const {task_id}=await f.command({op:'create',profile:f.profile,message:'Visible sidebar entry'});
 const deadline=Date.now()+10000;
 while(f.requests.length<=index && Date.now()<deadline)await delay(10);
 f.finish(index,{text:'Model finished.'});
 const task=await taskIdle(f.running.service,task_id);
 await page.waitForTimeout(500);
 const sidebar=await page.locator('body').evaluate(n=>[...n.querySelectorAll('nav,aside,[role="navigation"],[aria-label*="Task"],[aria-label*="task"]')].map(x=>({tag:x.tagName,role:x.getAttribute('role'),label:x.getAttribute('aria-label'),text:x.innerText,html:x.outerHTML}))); 
 console.log(JSON.stringify({projectGroup,menu,taskTitle:task.task.title,sidebar,body:await page.locator('body').innerText(),events},null,2));
}finally{for(const fn of clean.reverse())await fn();}
