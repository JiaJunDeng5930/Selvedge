import { appendFile } from 'node:fs/promises';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { browserFixture } from '/workspace/selvedge-reconstruction/tests/fixtures/browser.mjs';
import { taskIdle } from '/workspace/selvedge-reconstruction/tests/support.mjs';

async function submitTask(page) {
  const receipt = page.waitForResponse(response => response.url().endsWith('/api/browser/command')
    && response.request().method() === 'POST');
  await page.getByRole('button', { name: 'Start task', exact: true }).click();
  const response = await receipt;
  assert.equal(response.status(), 200);
  const { reply } = await response.json();
  assert.equal(reply.ok, true, JSON.stringify(reply));
  return reply.result.task_id;
}

async function projectTask(page) {
  await page.getByRole('navigation', { name: 'Task tree', exact: true })
    .getByRole('button', { name: 'Acceptance Project', exact: true }).click();
  await page.getByRole('button', { name: 'Start task', exact: true }).waitFor();
}


const cleanups=[];const t={after:fn=>cleanups.push(fn)};
try { await (async t => {
  const fixture = await browserFixture(t);
  const { page, command } = fixture;
  async function stage(name) { await appendFile('.workpad/ui-remigration/project-stages.jsonl', JSON.stringify({name,time:Date.now(),body:await page.locator('body').innerText()})+'\n'); }
  page.on('response',r=>{ if(r.url().includes('/api/browser/command')) console.log('BROWSER_COMMAND_RESPONSE',r.status()); });
  await stage('fixture');
  const root = path.join(fixture.root, 'Project workspace');
  await mkdir(root);
  await writeFile(path.join(root, 'AGENTS.md'), 'Use the Project acceptance instructions.');
  const { project_id } = await command({ op: 'create_project', name: 'Acceptance Project',
    workspace: { roots: [root], primary_root: root } });
  await page.getByRole('navigation', { name: 'Global navigation', exact: true })
    .getByRole('button', { name: '项目', exact: true }).click();
  await page.getByRole('main').getByRole('region', { name: 'Acceptance Project', exact: true }).hover();
  await page.getByRole('main').getByRole('button', { name: 'Project actions', exact: true }).click();
  await stage('before-details');
  await page.getByRole('button', { name: 'Project details', exact: true }).click();
  await stage('after-details');
  await page.getByRole('main').getByRole('button', { name: 'New task', exact: true }).waitFor();
  assert.ok((await page.getByRole('main').innerText()).includes(root));
  await page.getByText('Use the Project acceptance instructions.', { exact: true }).waitFor();
  await page.getByRole('main').getByRole('button', { name: 'New task', exact: true }).click();
  const start = page.getByRole('button', { name: 'Start task', exact: true });
  await start.waitFor();
  assert.equal(await start.isDisabled(), true, 'An empty Task remains a passive draft');
  await stage('before-workspace');
  await page.getByRole('button', { name: 'Workspace', exact: true }).click();
  await stage('after-workspace');
  let workspace = page.getByRole('dialog');
  await stage('before-remove');
  await workspace.getByRole('button', { name: 'Remove directory', exact: true }).click();
  await stage('after-remove');
  await stage('before-restore');
  await workspace.getByRole('button', { name: 'Use inherited workspace', exact: true }).click();
  await stage('after-restore');
  await workspace.getByRole('button', { name: 'Remove directory', exact: true }).waitFor();
  await page.keyboard.press('Escape');
  await workspace.waitFor({ state: 'hidden' });
  await page.getByRole('textbox', { name: 'Task', exact: true }).fill('Use inherited Project workspace');
  await stage('before-submitted-inherited');
  const inherited = await submitTask(page);
  await stage('after-submitted-inherited');
  const inheritedTask = (await command({ op: 'read', task_id: inherited })).task;
  assert.equal(inheritedTask.settings.project_id, project_id);
  assert.deepEqual(inheritedTask.settings.workspace, { roots: [root], primary_root: root });

  await stage('before-second-draft');
  await projectTask(page);
  await stage('after-second-draft');
  await stage('before-workspace');
  await page.getByRole('button', { name: 'Workspace', exact: true }).click();
  await stage('after-workspace');
  workspace = page.getByRole('dialog');
  await stage('before-remove');
  await workspace.getByRole('button', { name: 'Remove directory', exact: true }).click();
  await stage('after-remove');
  await workspace.getByRole('button', { name: 'Use inherited workspace', exact: true }).waitFor();
  await page.keyboard.press('Escape');
  await workspace.waitFor({ state: 'hidden' });
  await page.getByRole('textbox', { name: 'Task', exact: true }).fill('Use explicitly no workspace roots');
  await stage('before-submitted-empty');
  const empty = await submitTask(page);
  await stage('after-submitted-empty');
  const emptyTask = (await command({ op: 'read', task_id: empty })).task;
  assert.equal(emptyTask.settings.project_id, project_id);
  assert.deepEqual(emptyTask.settings.workspace, { roots: [], primary_root: null },
    'Explicitly removing roots must not silently return to Project inheritance');

})(t); console.log('PROBE_SUCCESS'); } finally { for(const cleanup of cleanups) await cleanup(); }
