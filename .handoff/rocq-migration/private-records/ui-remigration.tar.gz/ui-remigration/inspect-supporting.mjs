import { browserFixture } from '../../tests/fixtures/browser.mjs';
import { mkdir } from 'node:fs/promises';
import path from 'node:path';
const clean=[],t={after(fn){clean.push(fn);}};
try{
 const f=await browserFixture(t),{page}=f,workspace=path.join(f.root,'A readable workspace directory for supporting controls');await mkdir(workspace);
 await page.setViewportSize({width:1920,height:1000});
 await f.command({op:'create_project',name:'Responsive controls acceptance',workspace:{roots:[workspace],primary_root:workspace}});
 await page.getByRole('navigation',{name:'Global navigation',exact:true}).getByRole('button',{name:'项目',exact:true}).click();
 await page.getByRole('main').getByRole('button',{name:'Responsive controls acceptance',exact:true}).click();
 await page.getByRole('textbox',{name:'Task',exact:true}).fill('Measure the responsive controls.');
 await page.waitForTimeout(1000);
 const group=page.getByLabel('Supporting controls',{exact:true});
 const observe=()=>group.evaluate(n=>({text:n.innerText,rect:n.getBoundingClientRect().toJSON(),html:n.outerHTML,ancestors:[n.parentElement,n.parentElement.parentElement].map(x=>({attrs:[...x.attributes].map(a=>[a.name,a.value]),rect:x.getBoundingClientRect().toJSON()}))}));
 const wide=await observe();await page.setViewportSize({width:320,height:1000});await page.waitForTimeout(3000);const narrow=await observe();
 console.log(JSON.stringify({wide,narrow},null,2));
}finally{for(const fn of clean.reverse())await fn();}
