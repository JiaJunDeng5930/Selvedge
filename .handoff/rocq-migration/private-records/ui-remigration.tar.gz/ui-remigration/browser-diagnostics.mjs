import { chromium } from 'playwright-core';
import { writeFile, mkdir } from 'node:fs/promises';
const directory=new URL('./browser-diagnostics/',import.meta.url);
await mkdir(directory,{recursive:true});
const launch=chromium.launch.bind(chromium);
chromium.launch=async(...args)=>{
 const browser=await launch(...args), observations=new Map();
 browser.on('context',()=>{});
 const newPage=browser.newPage.bind(browser);
 browser.newPage=async(...pageArgs)=>{
  const page=await newPage(...pageArgs), events=[];observations.set(page,events);
  page.on('pageerror',error=>events.push({kind:'pageerror',error:String(error),stack:error.stack}));
  page.on('console',message=>{if(message.type()==='error')events.push({kind:'console',message:message.text(),location:message.location()});});
  page.on('request',request=>{const u=new URL(request.url());if(u.pathname.startsWith('/api/'))events.push({kind:'request',path:u.pathname,method:request.method(),body:request.postData()});});
  page.on('response',async response=>{const u=new URL(response.url());if(u.pathname.startsWith('/api/')&&response.headers()['content-type']?.includes('application/json'))events.push({kind:'response',path:u.pathname,status:response.status(),body:await response.text().catch(error=>String(error))});});
  return page;
 };
 const close=browser.close.bind(browser);
 browser.close=async(...closeArgs)=>{
  for(const [page,events] of observations){
   if(!page.isClosed()){
    const id=String(Date.now())+'-'+new URL(page.url()).port;
    const body=await page.locator('body').innerText().catch(error=>String(error));
    const html=await page.content().catch(error=>String(error));
    await writeFile(new URL(id+'.json',directory),JSON.stringify({body,html,events},null,2));
   }
  }
  return close(...closeArgs);
 };
 return browser;
};
