import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { browserFixture } from '../../tests/fixtures/browser.mjs';

const cleanups = [];
const fixture = await browserFixture({ after: cleanup => cleanups.push(cleanup) });
const { page, root, command } = fixture;
const events = [], states = [];
let release, prepared, held = false;
const gate = new Promise(resolve => { release = resolve; });
const preparation = new Promise(resolve => { prepared = resolve; });
const record = (type, value) => events.push({ time: Date.now(), type, ...value });
page.on('request', request => {
  if (request.url().includes('/api/')) record('request', { url: request.url(), method: request.method(), body: request.postData() });
});
page.on('response', async response => {
  if (!response.url().includes('/api/') || !response.headers()['content-type']?.includes('application/json')) return;
  try { record('response', { url: response.url(), status: response.status(), body: await response.text() }); }
  catch (error) {
    // DEFENSE: Closing this diagnostic fixture can cancel an in-flight response body read.
    record('response-read-error', { url: response.url(), error: String(error) });
  }
});
page.on('console', message => record('console', { level: message.type(), text: message.text() }));
page.on('pageerror', error => record('pageerror', { error: String(error) }));
async function snapshot(step) {
  states.push({ step, body: await page.locator('body').innerText(), html: await page.locator('body').innerHTML(),
    controls: await page.locator('button').evaluateAll(nodes => nodes.map(node => ({
      label: node.getAttribute('aria-label'), text: node.innerText, title: node.getAttribute('title'), disabled: node.disabled }))),
    dialogs: await page.getByRole('dialog').evaluateAll(nodes => nodes.map(node => ({ label: node.getAttribute('aria-label'),
      labelledby: node.getAttribute('aria-labelledby'), text: node.innerText }))) });
}
try {
  const workspace = path.join(root, 'Captured directory diagnostic');
  await mkdir(workspace);
  await command({ op: 'create_project', name: 'Diagnostic Project', workspace: { roots: [workspace], primary_root: workspace } });
  await page.getByRole('navigation', { name: 'Global navigation', exact: true }).getByRole('button', { name: '项目', exact: true }).click();
  await page.getByRole('main').getByRole('button', { name: 'Diagnostic Project', exact: true }).waitFor();
  await snapshot('project-list');
  await page.route('**/api/browser/observation', async route => {
    const request = route.request().postDataJSON();
    record('routed-observation', { request });
    if (request.kind !== 'directories' || held) return route.continue();
    held = true;
    record('directory-held', {});
    const response = await route.fetch();
    record('directory-fetched', { status: response.status() });
    prepared();
    await gate;
    await route.fulfill({ response });
  });
  await page.getByRole('main').getByRole('button', { name: 'Diagnostic Project', exact: true }).click();
  const draft = page.getByRole('textbox', { name: 'Task', exact: true });
  await draft.fill('Run exactly this captured submission.');
  await snapshot('before-start');
  await page.getByRole('button', { name: 'Start task', exact: true }).click();
  const observed = await Promise.race([preparation.then(() => true), delay(10000).then(() => false)]);
  record('preparation-observed', { observed, held });
  await snapshot('after-start');
  if (observed) {
    await draft.fill('Keep this later unsent draft.');
    await page.getByRole('navigation', { name: 'Global navigation', exact: true }).getByRole('button', { name: '智能体', exact: true }).click();
  }
  release();
  await delay(1000);
  await snapshot('after-release');
  await page.setViewportSize({ width: 450, height: 900 });
  const launcher = page.getByRole('button', { name: 'Open Task list', exact: true });
  if (await launcher.count()) await launcher.click();
  await snapshot('narrow-dialog');
} finally {
  release();
  await writeFile('.workpad/ui-remigration/public-ui-diagnostic.json', JSON.stringify({ events, states }, null, 2));
  for (const cleanup of cleanups) await cleanup();
}
