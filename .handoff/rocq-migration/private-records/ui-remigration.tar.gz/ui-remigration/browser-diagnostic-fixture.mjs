import { writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { access } from 'node:fs/promises';
import { constants } from 'node:fs';
import { chromium } from 'playwright-core';
import { interactiveMarkdownFixture } from '/workspace/selvedge-reconstruction/tests/fixtures/interactive-markdown.mjs';
import { imagesFixture } from '/workspace/selvedge-reconstruction/tests/fixtures/images.mjs';

async function chromiumExecutable() {
  const requested = process.env.SELVEDGE_CHROMIUM_EXECUTABLE_PATH;
  if (requested) {
    await access(requested, constants.X_OK);
    return requested;
  }
  for (const filename of ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome']) {
    try {
      await access(filename, constants.X_OK);
      return filename;
    } catch (error) {
      // DEFENSE: Linux distributions install Chromium under different executable names.
      if (error.code !== 'ENOENT') throw error;
    }
  }
  throw new Error('Browser acceptance requires Chromium. Install it or set SELVEDGE_CHROMIUM_EXECUTABLE_PATH.');
}

/** Only the loopback model is controlled; pages use the complete authenticated server. */
export async function browserFixture(t, { images = false } = {}) {
  const fixture = images ? await imagesFixture(t) : await interactiveMarkdownFixture();
  if (!images) t.after(() => fixture.close());
  const browser = await chromium.launch({ executablePath: await chromiumExecutable(), headless: true });
  t.after(async () => {
    try {
      const data = await page.evaluate(() => ({ body: document.body.innerText, html: document.body.innerHTML,
        buttons: [...document.querySelectorAll('button')].map(node => ({ label: node.getAttribute('aria-label'), text: node.innerText, disabled: node.disabled })),
        landmarks: [...document.querySelectorAll('main,nav,ul,ol,[role]')].map(node => ({ tag: node.tagName, role: node.getAttribute('role'), label: node.getAttribute('aria-label'), text: node.innerText.slice(0,300) })) }));
      await writeFile('/workspace/selvedge-reconstruction/.workpad/ui-remigration/browser-diagnostics/' + Date.now() + '.json', JSON.stringify({test:t.name,events:diagnosticEvents,...data},null,2));
    } finally { await browser.close(); }
  });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  page.setDefaultTimeout(10000);
  const diagnosticEvents = [];
  page.on('request', request => { if (request.url().includes('/api/')) diagnosticEvents.push({type:'request',url:request.url(),method:request.method(),body:request.postData()}); });
  page.on('response', response => { if (response.url().includes('/api/')) diagnosticEvents.push({type:'response',url:response.url(),status:response.status()}); });
  page.on('console', message => diagnosticEvents.push({type:'console',level:message.type(),text:message.text()}));
  const errors = [];
  page.on('pageerror', error => errors.push(String(error)));
  t.after(() => assert.deepEqual(errors, [], 'The browser must remain operational throughout the workflow'));
  async function command(value) {
    const response = await fetch(`${fixture.running.address}/api/commands`, {
      method: 'POST', headers: { authorization: `Bearer ${fixture.running.token}`, 'content-type': 'application/json' },
      body: JSON.stringify(value),
    });
    assert.equal(response.status, 200, await response.clone().text());
    const reply = await response.json();
    assert.equal(reply.ok, true, JSON.stringify(reply));
    return reply.result;
  }
  await page.goto(fixture.running.url);
  await page.getByRole('navigation', { name: 'Global navigation', exact: true }).waitFor();
  return { ...fixture, get running() { return fixture.running; }, page, browser, command,
    profile: images ? fixture.profile : 'interactive' };
}
