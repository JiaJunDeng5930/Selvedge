# Browser layout responsibility audit

Reference: `acfbe86d8181415fd887c323cbba6495509d280f`.
Continuation base: `6834161f25d8901406f132a34f60edcc31ac6ae6`.
This is a private audit, not a completion ledger or a declaration that the UI is migrated.

## Current mechanism and the repaired responsibility

The current layout does not expose the original generic allocation engine.
`Layout` owns dimensions, font-dependent parameters, region capacity and whole-row
direction. `Typography` owns exact font specifications. `Observation` validates
font and region observations. `Document` emits native DOM/CSS. The physical
interpreter obtains observations from those actual nodes.

The original `MODEL.receive` and `CONTRACT.stale_claim` make receipt generation
admission a pure decision and ignore a stale payload without decoding it.
Previously `app.mjs::refreshPhysical` implemented that decision with a JavaScript
comparison. The new `Observation.current_measurement` and
`Runtime.environment_call` admit the batch in Gallina. The app now supplies its
captured and current publication generations and interprets the returned stale
or admitted result. No second generation counter or persistent state was added.
The same batch owns font, region and responsive-row observations; a stale result
continues before any of them can be applied.

`MeasurementProof` binds stale rejection and valid environment admission to the
actual extracted `Runtime.call "environment"` entry. It also proves actual font
lookup selects the first complete valid same-key record, preserves its positive
height/advance, and rejects matched regions with no complete valid dimensions.
The selector reuses the existing metric parser, and region width/height must
come from one complete record. No fields are merged across receipts. A truly
absent region remains explicit pending; an incomplete matched region is rejected.

`RenderProof` binds complete ordered native fence payloads to actual
`Document.compile_node`: the owner/view identifies the mount and the complete
child list is compiled in order. It also binds rest paint channels to the actual
style producer and disabled action state to the actual native button producer.
Both proof modules passed the existing builder's Rocq module check. Production
extraction and browser regression still need the latest selector change.
Actual browser acceptance is owned by the independent test agent.

## Per-original-file disposition

All thirteen files remain **pending**. Repairing stale admission closes one
responsibility, not any whole original file. Existing completed browser files
were not reopened.

| Original file | Established current responsibility | Remaining obligation before closure |
| --- | --- | --- |
| `CONTENT.bend` | Typed positive font metrics, environment parameters and explicit missing region observations are in `Layout`/`Observation`; the actual DOM has native source ownership. | Map the complete source snapshot/native-root/native-policy/prepared/allocated vocabulary and its errors, including duplicate owner/target slots, to the real current document and physical boundary. Current environment records alone do not establish these obligations. |
| `CONTRACT.bend` | `LayoutProof` constrains actual capacity and whole-row selection; `MeasurementProof` now constrains actual stale admission. | Bind invalid/duplicate measurement rejection and the complete production preparation/population obligations to current executable operations. Do not substitute the new stale theorem for the whole contract. |
| `MODEL.bend` | Actual font/environment decoding and publication-generation admission execute through `Runtime.environment_call`; first-complete-valid font/region lookup is shared and proved; responsive decisions execute through `Runtime.responsive_rows`. | Close the full measurement/target receipt admission, complete batch failure, request membership, duplicate rejection, identity replacement and preparation lifecycle semantics. The former engine's functions cannot all be accounted for by an environment decoder. |
| `PROOF.bend` | Existing dedicated production proofs provide some geometry, capacity, publication and typography evidence. | Supply the original complete receipt/lifecycle evidence against actual preparation and publication operations; then assemble the required production instances. |
| `RENDERER.bend` | `Document.compile_node` and the physical renderer realize current domain nodes and native carriers with domain-owned properties. `RenderProof` establishes complete ordered fence payload preservation directly at their owner/view mount, avoiding a disconnected `Owned` filter model. | Verify all source/font/wrapping realizations, complete native-root/native-policy validity and rejection, and exact carrier preservation at the still-pending document/source admission boundary. |
| `measurement-contract.bend` | Publication generations, prepared/published phases and environment absence are explicit current concepts. | Establish complete first-valid receipt selection, request/native-owner/purpose correspondence, viewport lookup, width-specific lookup, and missing-measurement lifecycle against the current operations. |
| `measurement-proof.bend` | The new stale theorem covers one real receipt admission case; existing typed metrics exclude zero font observations. | Establish the independent complete dimension/preparation claims from `measurement-requirements.bend` against actual current admission, including rejection and completion cases. |
| `measurement-requirements.bend` | Font observations have positive height/advance by construction; absent allocated regions remain pending. | Preserve the full distinction among natural, width-constrained, empty text and owned interactive targets, exact generation/key/purpose matching, and complete preparation admission. No current theorem establishes the entire predicate family. |
| `physical-content-measurement.bend` | Physical observations come from the actual DOM; the new pure generation boundary rejects an entire stale batch. | Complete request/owner/purpose/dimension matching and first-complete-valid receipt semantics, including the restricted zero-height owned-interactive case. DOM observation alone does not prove receipt admissibility. |
| `render-contract.bend` | Pure declarations own current chrome/typography/control properties and actual DOM metadata. `RenderProof` binds rest channels, disabled native controls and complete ordered fence payloads to actual production functions. | Bind the remaining `TextSpaceRequirements` and `RendererRequirements`, especially observed fields/toggles, reading/content reserves, source correspondence and admitted/rejected native worlds. |
| `render-proof.bend` | Existing document/typography/layout proof modules constrain some emitted properties. | Prove the full renderer contract against the current emitted DOM vocabulary and actual carriers, rather than importing a renamed record or proving a disconnected reference renderer. |
| `sizing-proof.bend` | Current font dimensions, motor minima, writing lines and row/capacity bounds have dedicated proofs. | Close all complete receipt lookup, width-specific height, native ownership and prepared-allocation correspondence required by the original sizing provider. |
| `README.md` | Current Browser README states the native layout and physical trust boundary. | Close and document the missing measurable receipt/preparation responsibilities above; a replacement architecture description does not establish their preservation. |

## Concrete follow-up checks

1. **Repaired and proved:** keyed lookup now selects the first *complete valid*
   record. A matched region without complete width/height is rejected instead of
   becoming the `JNull` reserved for a genuinely absent region. Complete records
   are preserved, and no partial fields are combined.
2. Original receipt identity includes exact measurement purpose and, for native
   viewports, owner/target correspondence. Native layout may remove the need for
   a cached allocation engine, but it does not remove the product obligations
   concerning whose observed content is measured and published.
3. Preserve the current mechanism where it already satisfies a responsibility.
   Do not copy the old `Engine` into an unused parallel model merely to obtain
   original-looking theorem names.

## Evidence

- Raw fixed-reference originals are retained under `layout-original/`.
- `node --check host/public/app.mjs`: passed after the pure batch admission change.
- `git diff --check`: passed after the pure batch admission change.
- Coordinating agent reported production browser extraction completed with pure
  generation admission. The later complete-valid selector awaits re-extraction.
- `bun scripts/build.mjs --module Browser.MeasurementProof,Browser.RenderProof`:
  passed; `layout-proof-check.log` retains the actual output.
- No original-file completion markers changed in this block.
