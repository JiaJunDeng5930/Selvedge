import { appendFile } from 'node:fs/promises';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { browserFixture } from '/workspace/selvedge-reconstruction/tests/fixtures/browser.mjs';
import { taskIdle } from '/workspace/selvedge-reconstruction/tests/support.mjs';

async function submitTask(page) {
  const receipt = page.waitForResponse(response => response.url().endsWith('/api/browser/command')
    && response.request().method() === 'POST');
  await page.getByRole('button', { name: 'Start task', exact: true }).click();
  const response = await receipt;
  assert.equal(response.status(), 200);
  const { reply } = await response.json();
  assert.equal(reply.ok, true, JSON.stringify(reply));
  return reply.result.task_id;
}

async function projectTask(page) {
  await page.getByRole('navigation', { name: 'Task tree', exact: true })
    .getByRole('button', { name: 'Acceptance Project', exact: true }).click();
  await page.getByRole('button', { name: 'Start task', exact: true }).waitFor();
}


const cleanups=[];const t={after:fn=>cleanups.push(fn)};try{await (async t=>{
  const fixture = await browserFixture(t);
  const { page, command } = fixture;
  const events=[];
  async function stage(name) { await appendFile('.workpad/ui-remigration/graph-stages.jsonl',JSON.stringify({name,time:Date.now(),body:await page.locator('body').innerText(),events})+'\n'); }
  page.on('pageerror',error=>events.push({type:'pageerror',error:String(error)}));
  page.on('console',m=>{if(m.type()==='error')events.push({type:'console',text:m.text()});});
  page.on('response',r=>{if(r.status()>=400)events.push({type:'response',path:new URL(r.url()).pathname,status:r.status()});});
  await stage('fixture');
  const alpha = await command({ op: 'create_idle', profile: 'demo' });
  const beta = await command({ op: 'create_idle', profile: 'demo' });
  const graph = await command({ op: 'create_task_graph', name: 'Acceptance workflow',
    nodes: [{ key: 'alpha', task_id: alpha.task_id }, { key: 'beta', task_id: beta.task_id }],
    rules: [{ key: 'flow', source: 'alpha', actions: [{ target: 'beta', message: { kind: 'output' } }] }],
  });
  const source = `<ui id="acceptanceGraph">
<state id="count" type="integer" initial={0} min={0} max={20} />
<state id="note" type="string" initial="" />
<source id="workflow" kind="task-graph" graph-id={${graph.graph_id}} mode="live" />
<stack id="root">
<text id="count-label" label={"Count: " + text(count)} />
<text-input id="note-entry" bind="note" label="Shared note" />
<resource-view id="live" source="workflow" let="graph">
<graph-view id="diagram" nodes={graph.nodes} edges={graph.edges} node-key="identity" layout="stable" label="Acceptance workflow">
<node-template item="node"><stack id="node-body">
<text id="node-name" label={node.key} />
<button id="node-action" label={"Increment " + node.key} action="set" target="count" value={count + 1} />
</stack></node-template>
</graph-view>
</resource-view>
</stack>
</ui>`;
  async function viewer(title) {
    const index = fixture.requests.length;
    const { task_id } = await command({ op: 'create', profile: fixture.profile, message: title });
    const deadline = Date.now() + 5000;
    while (fixture.requests.length <= index && Date.now() < deadline) await delay(10);
    assert.ok(fixture.requests.length > index, 'The complete service must request the viewer reply from its model');
    fixture.finish(index, { text: '```selvedge-ui\n' + source + '\n```' });
    const { task } = await taskIdle(fixture.running.service, task_id);
    await page.getByRole('navigation', { name: 'Task tree', exact: true })
      .getByRole('button').filter({ hasText: task.title }).click();
    await page.getByRole('button', { name: 'Increment alpha', exact: true }).waitFor();
    return task.title;
  }
  const title = await viewer('Graph interaction acceptance');
  await stage('viewer-ready');
  assert.match(await page.getByRole('list', { name: '图节点状态', exact: true }).innerText(), /alpha[\s\S]*beta/);
  assert.match(await page.getByRole('list', { name: '连接规则', exact: true }).innerText(), /flow/);
  await page.getByRole('button', { name: 'Increment alpha', exact: true }).click();
  await page.getByText('Count: 1', { exact: true }).waitFor();
  await page.getByRole('textbox', { name: 'Shared note', exact: true }).fill('One persistent logical note');
  await page.getByRole('button', { name: 'Increment beta', exact: true }).click();
  await page.getByText('Count: 2', { exact: true }).waitFor();
  assert.equal(await page.getByRole('textbox', { name: 'Shared note', exact: true }).inputValue(), 'One persistent logical note');
  await page.getByRole('button', { name: '右移', exact: true }).click();
  const panned = await page.getByRole('button', { name: 'Increment alpha', exact: true }).boundingBox();
  await page.getByRole('button', { name: '适应宽度', exact: true }).click();
  await page.waitForFunction(x => {
    const action = [...document.querySelectorAll('button')].find(node => node.textContent === 'Increment alpha');
    return action && action.getBoundingClientRect().x !== x;
  }, panned.x);
  for (let step = 0; step < 3; step++) await page.getByRole('button', { name: '缩小', exact: true }).click();
  const first = await page.getByRole('button', { name: 'Increment alpha', exact: true }).boundingBox();
  const second = await page.getByRole('button', { name: 'Increment beta', exact: true }).boundingBox();
  assert.ok(first.width >= 24 && first.height >= 24 && second.width >= 24 && second.height >= 24,
    'Zoom preserves operable node controls');
  assert.ok(first.x + first.width <= second.x || second.x + second.width <= first.x
    || first.y + first.height <= second.y || second.y + second.height <= first.y,
  'Different node controls must not overlap at low zoom');
  await stage('before-reload');
  await page.reload();
  await stage('after-reload');
  await stage('before-reopen-title');
  await page.getByRole('navigation', { name: 'Task tree', exact: true }).getByRole('button').filter({ hasText: title }).click();
  await stage('after-reopen-title');
  await page.getByText('Count: 2', { exact: true }).waitFor();
  assert.equal(await page.getByRole('textbox', { name: 'Shared note', exact: true }).inputValue(), 'One persistent logical note');
  const invalid = await page.evaluate(() => {
    const [key, raw] = Object.entries(localStorage).find(([key]) => key.startsWith('selvedge-interactive-v1/'));
    const snapshot = JSON.parse(raw);
    snapshot.payload.locals.find(local => local.id === 'count').value = 'invalid integer';
    snapshot.payload.locals.find(local => local.id === 'note').value = 'Must not partially restore';
    return [key, JSON.stringify(snapshot)];
  });
  await page.evaluate(([key, raw]) => localStorage.setItem(key, raw), invalid);
  await stage('before-reload');
  await page.reload();
  await stage('after-reload');
  await stage('before-reopen-title');
  await page.getByRole('navigation', { name: 'Task tree', exact: true }).getByRole('button').filter({ hasText: title }).click();
  await stage('after-reopen-title');
  await page.getByText('Count: 0', { exact: true }).waitFor();
  assert.equal(await page.getByRole('textbox', { name: 'Shared note', exact: true }).inputValue(), '',
    'An invalid persisted field must reject the whole restoration before any other field is applied');
  await viewer('Independent graph document');
  await page.getByText('Count: 0', { exact: true }).waitFor();
  assert.equal(await page.getByRole('textbox', { name: 'Shared note', exact: true }).inputValue(), '',
    'The same definition in another Task must not acquire the first Task\'s stored state');

})(t);console.log('PROBE_SUCCESS');}finally{for(const cleanup of cleanups)await cleanup();}
