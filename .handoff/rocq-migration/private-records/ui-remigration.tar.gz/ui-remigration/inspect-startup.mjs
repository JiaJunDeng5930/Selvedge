import { chromium } from 'playwright-core';
import { interactiveMarkdownFixture } from '../../tests/fixtures/interactive-markdown.mjs';
const fixture=await interactiveMarkdownFixture();
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
try {
 const page=await browser.newPage();
 const events=[];
 page.on('pageerror',e=>events.push({kind:'pageerror',message:String(e),stack:e.stack}));
 page.on('console',m=>events.push({kind:'console',type:m.type(),message:m.text(),location:m.location()}));
 page.on('requestfailed',r=>events.push({kind:'requestfailed',url:r.url(),error:r.failure()}));
 page.on('response',async r=>{const u=new URL(r.url()); if(u.pathname.startsWith('/api/')){const raw=await r.text().catch(()=>null);let body;try{body=JSON.parse(raw)}catch{};events.push({kind:'response',path:u.pathname,status:r.status(),keys:body?Object.keys(body):[],error:body?.error});}});
 await page.goto(fixture.running.url);
 await page.waitForTimeout(4000);
 console.log(JSON.stringify({url:page.url(),body:await page.locator('body').innerText(),events},null,2));
}finally{await browser.close();await fixture.close();}
