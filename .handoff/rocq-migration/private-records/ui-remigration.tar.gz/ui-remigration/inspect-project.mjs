import { browserFixture } from '../../tests/fixtures/browser.mjs';
const clean=[]; const t={after(fn){clean.push(fn);}};
try {
 const f=await browserFixture(t); const {page}=f; const events=[];
 page.on('pageerror',e=>events.push({kind:'pageerror',message:String(e),stack:e.stack}));
 page.on('console',m=>{if(m.type()==='error')events.push({kind:'console',message:m.text(),location:m.location()});});
 await f.command({op:'create_project',name:'Inspect Project Page',workspace:{roots:[f.root],primary_root:f.root}});
 await page.getByRole('navigation',{name:'Global navigation',exact:true}).getByRole('button',{name:'项目',exact:true}).click();
 await page.getByRole('main').getByRole('button',{name:'Inspect Project Page',exact:true}).click();
 await page.waitForTimeout(1000);
 console.log(JSON.stringify({body:await page.locator('body').innerText(),events},null,2));
 await page.screenshot({path:'.workpad/ui-remigration/project-observation.png',fullPage:true});
}finally{for(const fn of clean.reverse())await fn();}
